#!/bin/python3
from files.lang import *
slogo()
lang()
mm()
